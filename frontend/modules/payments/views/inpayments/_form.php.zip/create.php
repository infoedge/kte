<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model frontend\modules\payments\models\Inpayments */

$this->title = Yii::t('app', 'Indicate Payment');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Inpayments'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="inpayments-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
<?php
$script = <<< JS
$(function (){
         
    $('#inpayments-package').change( function(){
        var packid = $(this).val();
        var ptype = $('#inpayments-ptype').val();
        //alert("Package: " + packid + "; Trx Type: " + ptype);
        $.get('index.php?r=payments/inpayments/pack-value',
             { packid : packid , ptype : ptype },
             function(data){
                var response = $.parseJSON(data);
                //alert('data: '+ response.amount);
                    $('#inpayments-amount').val(response.amount);
        });
                  
    });
    /*$('#inpayments-pmethod').change(function(){
        var pmethod= $('#inpayments-pmethod option:selected').val();
        
        //alert('Payment Method: ' + pmethod);
        if(pmethod==5){
            var memid = $('#inpayments-member option:selected').val();
            $.get('index.php?r=payments/inpayments/check-gcodes',
                    { memid : memid }
                    function(data){
                        var response = $.parseJSON(data);
                        //alert('data: '+ response.amount);
                        $('#inpayments-package').val(response.package);
                    });
            }
        
    });*/
 });
JS;
$this->registerJs($script);
?>